# graph_annotation2 > 2024-06-18 8:42am
https://universe.roboflow.com/dhruv-abbi/graph_annotation2

Provided by a Roboflow user
License: CC BY 4.0

